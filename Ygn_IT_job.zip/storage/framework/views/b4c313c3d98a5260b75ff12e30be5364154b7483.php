<?php $__env->startSection('content'); ?>
	
	<h1 class="text-center">Create Category</h1>
	<div class="container-fluid">
		<div class="row">
			<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-info float-right mb-3">Back</a>
			<div class="col-md-12">
				<form class="form-group" method="post" action="<?php echo e(route('categories.store')); ?>">
					<?php echo csrf_field(); ?>
					<label for="name" class="font-weight-bold">Name</label>
					<input type="text" id="name" name="name" class="form-control">
					<div class="mt-3">
					<input type="submit" name="" value="Save" class="btn btn-primary">
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/categories/create.blade.php ENDPATH**/ ?>