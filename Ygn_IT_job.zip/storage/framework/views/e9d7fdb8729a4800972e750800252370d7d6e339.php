<?php $__env->startSection('content'); ?>
	<h1 class="text-center"></h1>
	<h1 class="text-center">Edit Category</h1>
	<div class="container-fluid">
		<div class="row">
			<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-info float-right mb-3">Back</a>
			<div class="col-md-12">
				<form class="form-group" method="post" action="<?php echo e(route('categories.update',$category->id)); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<label for="name" class="font-weight-bold">Name</label>
					<input type="text" id="name" name="name" class="form-control" value="<?php echo e($category->name); ?>">
					<div class="mt-3">
					<input type="submit" name="" value="Save" class="btn btn-primary">
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/categories/edit.blade.php ENDPATH**/ ?>