<?php $__env->startSection('content'); ?>
	<h1 class="text-center">Register Job</h1>
	<div class="container-fluid">
		<div class="row">
			<a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-outline-info float-right mb-3">Back</a>

			<?php if($errors->any()): ?>
		
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>


			<div class="col-md-12">
				<form class="form-group" method="post" action="<?php echo e(route('jobs.update',$job->id)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<label for="name" class="font-weight-bold">Name</label>
					<input type="text" id="name" name="name" class="form-control mb-4" value="<?php echo e($job->name); ?>">


					<label for="description" class="font-weight-bold">Description</label>
					<textarea id="description" name="description" class="form-control mb-4 <?php echo e(($errors->first('description') ? "form-error" : "")); ?>"><?php echo e($job->description); ?></textarea>
					<span class="text-danger"><?php echo e($errors->first('description')); ?></span>


					<label class="font-weight-bold">Choose Company</label>
					<select name="company_id" class="form-control mb-4">
						<option>Choose Company</option>
						<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($row->id); ?>" <?php if($job->company_id == $row->id): ?><?php echo e('selected'); ?> <?php endif; ?>><?php echo e($row->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

					<label class="font-weight-bold">Choose Category</label>
					<select name="category_id" class="form-control mb-4">
						<option>Choose Category</option>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($row1->id); ?>" <?php if($job->category_id == $row1->id): ?><?php echo e('selected'); ?> <?php endif; ?>><?php echo e($row1->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>


					<label for="salary" class="font-weight-bold">Max-Salary</label>
					<input type="number" id="salary" name="salary" class="form-control mb-4" value="<?php echo e($job->salary); ?>">


					<label for="exp_yrs" class="font-weight-bold">Experience Years</label>
					<input type="number" id="exp_yrs" name="exp_yrs" class="form-control mb-4" value="<?php echo e($job->exp_yrs); ?>">

					
					<label class="font-weight-bold">Gender</label>
					<input type="radio" name="gender" value="male" id="male" class="mb-4" <?php echo e($job->gender == 'male' ? 'checked' : ''); ?>>
					<label for="male">Male</label>
					<input type="radio" name="gender" value="female" id="female" class="mb-4" <?php echo e($job->gender == 'female' ? 'checked' : ''); ?>>
					<label for="female">Female</label>

					<label class="font-weight-bold d-block">Choose Carrer Level</label>
					<select name="careerlevel" class="form-control mb-4">
						<option>Choose Career Level</option>
						<option value="Entry Level">Entry Level</option>
						<option value="Junior Level">Junior</option>
						<option value="Senior Level">Senior</option>
						<option value="Experienced Non-Manager">Experience Non-Manager</option>
						<option value="Manager">Manager</option>
					</select>


					<label class="font-weight-bold">Feature Status</label>
					<input type="radio" name="is_feature" value="1" id="feature" class="mb-4" <?php echo e($job->is_feature == '1' ? 'checked' : ''); ?> >
					<label for="feature">Feature</label>
					<input type="radio" name="is_feature" value="0" id="non-feature" class="mb-4" <?php echo e(($job->is_feature=="0")? "checked" : ""); ?>>
					<label for="non-feature">Non-Feature</label>

					<div class="mt-3">
					<input type="submit" value="Save" class="btn btn-primary">
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/jobs/edit.blade.php ENDPATH**/ ?>