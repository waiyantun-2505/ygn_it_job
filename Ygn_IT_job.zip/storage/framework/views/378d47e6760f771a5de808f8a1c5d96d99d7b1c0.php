

<?php $__env->startSection('content'); ?>
	
		<div class="container-fluid">
      <div class="row">
        
            <img src="<?php echo e($company->banner); ?>" height="auto" width="100%" class="" style="
              object-position: 0 0 ; object-fit: cover; max-height: 250px; " >
                
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-8 mx-auto headline">
          <ul class="list-group shadow mt-2">
              <!-- list group item-->
              <li class="list-group-item">
                  <!-- Custom content -->
                  
                    <div class="row">
                      <div class="col-lg-3 col-md-3 col-sm-3" >
                          <img src="<?php echo e($company->logo); ?>" alt="Generic placeholder image" class="img-fluid" width="100%" height="auto">
                      </div>
                      <div class="col-md-9 col-lg-9 col-sm-9">
                        <h3><?php echo e($company->name); ?></h3>
                        <hr style="border:1px solid grey; margin: 0;">
                        <div class="row mt-lg-2">
                        <div class="col-md-9 col-lg-9">
                          <label class="d-block" style="font-size:14px; font-weight: bold;">Address</label>
                          <span style="font-size: 13px; line-height: 1px;" class=" text-justify"><?php echo e($company->address); ?></span>
                        </div>

                        <div class="col-md-3 col-lg-3">
                          <label class="d-block" style="font-size:14px; font-weight: bold;">Contact Us</label>
                          <a href="<?php echo e($company->facebook); ?>"><i class="fab fa-facebook fa-2x"></i></a>

                          <a href="<?php echo e($company->instagram); ?>"><i class="fab fa-instagram fa-2x"></i></a>
                        </div>
                      </div>
                        
                      </div>

                      
                  </div> <!-- End -->
                  
              </li> <!-- End -->
              <!-- list group item--> 
          </ul> 
        </div>
      </div>
    </div>
    
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-lg-8 mx-auto">
          <h2 style="color:#4e1515;">Vision And Mission</h2>
          <p class="text-justify"><?php echo e($company->visi_misi); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-10 col-lg-10 mx-auto">
    <hr>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-lg-8 mx-auto">
          <h2 style="color:#4e1515;">What We Do</h2>
          <p class="text-justify"><?php echo e($company->what_do); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-10 col-lg-10 mx-auto">
    <hr>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-lg-8 mx-auto">
          <h2 style="color:#4e1515;">Our workplace and culture</h2>
          <p class="text-justify"><?php echo e($company->culture); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-10 col-lg-10 mx-auto">
    <hr>
    </div>

    <div class="col-md-10 col-lg-10 mx-auto">
    <h1>All <?php echo e($company->name); ?> Jobs</h1>
    </div>

    <div class="container-fluid">
      <div class="row">
          <div class="col-md-10 col-lg-10 mx-auto table-responsive-sm">
            <table class="table">
              <thead>
                <tr class="text-center">
                  <th scope="col">No</th>
                  <th scope="col">Position Name</th>
                  <th scope="col">Max Salary</th>
                  <th scope="col">Job Location</th>
                  <th scope="col">Posted On:</th>
                  <th scope="col">View</th>
                </tr>
              </thead>
              <tbody>
                <?php $i=1 ?>
               <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="text-center">
                    <td scope="col"><?php echo e($i++); ?></td>
                    <td scope="col"><?php echo e($row->name); ?></td>
                    <td scope="col"><?php echo e($row->salary); ?></td>
                    <td scope="col"><?php echo e($row->township); ?></td>
                    <td scope="col"><?php echo e($row->created_at->diffForHumans()); ?></td>
                    <td>
                      <a href="<?php echo e(route('jobdetail',$row->id)); ?>" class="btn search">View Job</a>
                    </td>
                  </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>



    
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waiyantun/Desktop/Ygn_IT_job/resources/views/frontend/companydetail.blade.php ENDPATH**/ ?>