<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/waiyantun/Desktop/Ygn_IT_job/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>