	
<?php $__env->startSection('content'); ?>
<h1 class="text-center">Showing Jobs Data</h1>
<?php if($errors->any()): ?>

		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>

	<?php endif; ?>
	<div class="container-fluid">
		<div class="row">
			<div class="ml-auto col-md-6">
			<a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-outline-info mb-3">Add New</a>
			</div>
			<div class="col-md-6">
			<a href="<?php echo e(route('extendjobs')); ?>" class="btn btn-outline-warning float-right mb-3">Extend Jobs</a>
			</div>
			<div class="col-lg-12 col-md-12">
				<table class="table table-bordered mt-3">
					<thead class="table-dark">
						<th>No</th>
						<th>Name</th>
						<th>Company</th>
						<th>Start Date</th>
						<th>End Date</th>
						<th>Salary</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php $i=1 ?>
						<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i++); ?></td>
								<td><?php echo e($row->name); ?></td>
								<td><?php echo e($row->company->name); ?></td>
								<td><?php echo e($row->start_date); ?></td>
								<td><?php echo e($row->end_date); ?></td>
								<td><?php echo e($row->salary); ?></td>
								<td>
									<a href="<?php echo e(route('jobs.show',$row->id)); ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
									<a href="<?php echo e(route('jobs.edit',$row->id)); ?>" class="btn btn-primary"><i class="far fa-edit"></i></a>
									<form method="post" action="<?php echo e(route('jobs.destroy',$row->id)); ?>" onsubmit="return comfirm('Are you sure?')" class="d-inline-block">
										<?php echo csrf_field(); ?>
										<?php echo method_field('DELETE'); ?>
										<button type="submit" class="btn btn-danger"><i class="fas fa-minus-circle"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/jobs/index.blade.php ENDPATH**/ ?>