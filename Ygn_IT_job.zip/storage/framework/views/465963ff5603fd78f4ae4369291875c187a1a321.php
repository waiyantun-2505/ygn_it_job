
	
<?php $__env->startSection('content'); ?>
<h1 class="text-center">Showing Companies Data</h1>
<?php if($errors->any()): ?>

		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>

	<?php endif; ?>
	<div class="container-fluid">
		<div class="row">
			
			<a href="<?php echo e(route('companies.create')); ?>" class="btn btn-outline-info float-right mb-3">Add New</a>
			<div class="col-lg-12 col-md-12">
				<table class="table table-bordered mt-3">
					<thead class="table-dark">
						<th>No</th>
						<th>Name</th>
						<th>No of Employee</th>
						<th>Address</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php $i=1 ?>
						<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i++); ?></td>
								<td><?php echo e($row->name); ?></td>
								<td><?php echo e($row->no_of_employee); ?></td>
								<td style="max-width: 200px;"><?php echo e($row->address); ?></td>
								<td>
									<a href="<?php echo e(route('companies.show',$row->id)); ?>" class="btn btn-info"><i class="fas fa-info-circle"></i></a>
									<a href="<?php echo e(route('companies.edit',$row->id)); ?>" class="btn btn-primary"><i class="far fa-edit"></i></a>
									<form method="post" action="<?php echo e(route('companies.destroy',$row->id)); ?>" onsubmit="return comfirm('Are you sure?')" class="d-inline-block">
										<?php echo csrf_field(); ?>
										<?php echo method_field('DELETE'); ?>
										<button type="submit" class="btn btn-danger"><i class="fas fa-minus-circle"></i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waiyantun/Desktop/Ygn_IT_job/resources/views/backend/companies/index.blade.php ENDPATH**/ ?>