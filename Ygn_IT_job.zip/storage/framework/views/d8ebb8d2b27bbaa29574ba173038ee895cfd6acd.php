	
<?php $__env->startSection('content'); ?>



	<div class="container-fluid">
		<div class="row">
			<div class="col-md-7 col-lg-7 mx-auto">
				<div class="page-header">
				
				<select id="employee" class="form-control">
				<option value="" selected="selected">Select Employee Name</option>
				<?php
					$companies = DB::table('companies')->get();
				?>
				<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<table class="table table-bordered mt-3">
					<thead class="table-dark">
						<tr>
							<th>No</th>
							<th>Job Name</th>
							<th>Township</th>
							<th>Start Date</th>
							<th>End Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody id="jobs">
						
					</tbody>
				</table>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">

		$.ajaxSetup({
		    headers: {
		        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		    }
		});

		$(document).ready(function(){
			$("#employee").change(function() {
			var id = $(this).find(":selected").val();
			var html="";
			var j=1;
			$.post('/search_company',{id:id},function(res){
				$.each(res,function(i,v){
					var  id = v.id;
					var name = v.name;
					var start_date = v.start_date;
					var end_date = v.end_date;
					var township = v.township;

					html+=`	<tr>
								<td>${j++}</td>
								<td>${name}</td>
								<td>${township}</td>

								<td>${start_date}</td>
								<td>${end_date}</td>
								<td>
									<a href="<?php echo e(route('search_seekers',':id')); ?>"  class="btn btn-outline-primary">View Applied Job</a>
								</td>
							</tr>
							`;


				html=html.replace(':id',v.id);
							
				});

				$("#jobs").html(html);	
			})

			});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/jobs/seeker_job.blade.php ENDPATH**/ ?>