

<?php $__env->startSection('content'); ?>
	 
    
		<div class="container my-2">			
			<div class="row">
        <div class="col-md-9 col-lg-9 mx-auto">
          <!-- List group-->
              <ul class="list-group shadow mt-2">
              <!-- list group item-->
                  <li class="list-group-item">
                  
                    <div class="row">
                    <div class="col-lg-4 col-md-4 my-auto">
                      <img src="<?php echo e($job->company->logo); ?>" alt="Generic placeholder image" width="50%" height="auto" class="ml-lg-5 order-1 order-lg-2 hover-shadow">
                    </div>

                    <div class="col-lg-8 col-md-8">
                      <div class="row">
                        <div class="col-lg-8 col-md-8">
                        <h3><?php echo e($job->name); ?></h3>
                        <a href="<?php echo e(route('companydetail',$job->company_id)); ?>">
                          <p class="font-italic font-weight-bold text-muted mb-0"><?php echo e($job->company->name); ?></p>
                          </a>
                        <div class="row" style="font-size: 0.8em;">
                        <div class="ml-0 col-md-4 col-lg-4 mt-2">
                          <span class="text-capitalize text-muted">Open To <i class="fas fa-angle-right mr-2" style="color: #4e1515;"></i><?php echo e($job->gender); ?></span>
                        </div>
                        <div class="col-lg-4 col-md-4 mt-2">
                          <span class="text-capitalize text-muted"><i class="fas fa-location-arrow mr-2" style="color: #4e1515;"></i><?php echo e($job->township); ?></span>
                        </div>
                        <div class="col-lg-4 col-md-4 mt-2">
                          <span class="text-muted"><?php echo e($job->careerlevel); ?></span>
                        </div>
                      </div>
                      </div>
                      <div class="col-lg-4 col-md-4 my-auto">
                        <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-1">
                          <i class="fas fa-dollar-sign pr-3" style="color: green;"></i>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-11 mr-0 p-0">
                          <?php if(auth()->guard()->guest()): ?>
                              <a class="text-decoration-none" href="<?php echo e(route('login')); ?>"><span class="small">Please Login First</span></a>
                              <?php else: ?>
                            <?php echo e($job->salary); ?>

                            <?php endif; ?>
                        </div>
                        </div>
                        
                      </div>
                      </div>
                    </div>

               </div>

               <hr>
                
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <h4 style="color: #ffc107;letter-spacing: 4px;">Job Description</h4>

                    <p class="ml-lg-5 ml-md-5"><?php echo $job->description; ?></p>
                  </div>
                </div>

                <hr>

                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <h4 style="color: #ffc107;letter-spacing: 4px;">Job Requirement</h4>

                    <p class="ml-lg-5 ml-md-5"><?php echo $job->requirement; ?></p>
                  </div>
                </div>

                <hr>

                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <h4 style="color: #ffc107;">About Our Company</h4>

                    <p class="ml-lg-5 ml-md-5"><?php echo e($job->company->what_do); ?></p>
                  </div>
                </div>

                
                <?php
                  $today = today();
                  $condition = DB::table('jobs')->where('start_date','<=',$today)->where('end_date','>=',$today)->where('id',$job->id)->first();
                ?>
                <?php if($condition): ?>

                  <hr>
                  
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    
                      <form method="post" action="<?php echo e(route('applyjob',$job->id)); ?>">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="job_id" value="<?php echo e($job->id); ?>">
                    <input type="submit" style="text-decoration: none; padding-right: 10px; padding-right:25px ;background-color: #ffc107;" class="btn search" value="Apply Job">
                    <?php if(session('message')): ?>
                      <p class="text-danger"><?php echo e(session('message')); ?></p>
                    <?php endif; ?>
                    
                    </form>
                    
                    
                  </div>
                </div>
                
                <?php endif; ?>
                      
                  </li> <!-- End -->
              <!-- list group item--> 
              </ul> 
             <!-- List group--> 
         
        </div>
      </div>
		</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
    var msg = '<?php echo e(Session::get('message')); ?>';
    var exist = '<?php echo e(Session::has('message')); ?>';
    if(exist){
      alert(message);
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/waiyantun/Desktop/Ygn_IT_job/resources/views/frontend/jobdetail.blade.php ENDPATH**/ ?>