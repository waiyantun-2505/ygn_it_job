<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid" style="height: 65vh;">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<h1 class="text-center"><?php echo e($job->name); ?></h1>
			</div>

			<div class="col-md-6 col-lg-6 mx-auto">
				<form class="form-group" method="post" action="<?php echo e(route('jobs.update',$job->id)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<div class="row">
					<div class="col-md-5 col-lg-5">
						<label>Start Date</label>
						<input type="date" name="start_date" class="form-control" value="<?php echo e($job->start_date); ?>">
					</div>
					<div class="col-md-5 col-lg-5">
						<label>End Date</label>
						<input type="date" name="end_date" class="form-control" value="<?php echo e($job->end_date); ?>">
					</div>
					<input type="hidden" name="name" value="<?php echo e($job->name); ?>">
					<input type="hidden" name="description" value="<?php echo e($job->description); ?>">
					<input type="hidden" name="township" value="<?php echo e($job->township); ?>">
					<input type="hidden" name="requirement" value="<?php echo e($job->requirement); ?>">
					<input type="hidden" name="gender" value="<?php echo e($job->gender); ?>">
					<input type="hidden" name="careerlevel" value="<?php echo e($job->careerlevel); ?>">
					<input type="hidden" name="salary" value="<?php echo e($job->salary); ?>">
					<input type="hidden" name="exp_yrs" value="<?php echo e($job->exp_yrs); ?>">
					<input type="hidden" name="category_id" value="<?php echo e($job->category_id); ?>">
					<input type="hidden" name="company_id" value="<?php echo e($job->company_id); ?>">
					<input type="hidden" name="is_feature" value="<?php echo e($job->is_feature); ?>">
					</div>

					<div class="col-md-12 col-lg-12 mt-3">
						<div class="row">
						<div class="col-md-6 col-lg-6">
							<input type="submit" name="" class="btn btn-warning" value="Extend Date">
						</div>
						<div class="col-md-6 col-lg-6">
							<a href="<?php echo e(route('extendjobs')); ?>" class="btn btn-danger">Back</a>
						</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/jobs/extend_job.blade.php ENDPATH**/ ?>