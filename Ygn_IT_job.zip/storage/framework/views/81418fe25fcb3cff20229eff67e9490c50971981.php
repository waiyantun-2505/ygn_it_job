<?php $__env->startSection('content'); ?>
		
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<table class="table table-bordered mt-3">
					<thead class="table-dark">
						<tr>
							<th>No</th>
							<th>Seeker Name</th>
							<th>Phone</th>
							<th>Address</th>
							<th>Applied Date</th>
						</tr>
					</thead>
					<tbody>
						<?php $i=1; ?>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i++); ?></td>
								<td><?php echo e($user->name); ?></td>
								<td><?php echo e($user->phone); ?></td>
								<td><?php echo e($user->address); ?></td>
								<td><?php echo e($user->updated_at); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>
				</table>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backendtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ygn_IT_job\resources\views/backend/jobs/search_seekers.blade.php ENDPATH**/ ?>